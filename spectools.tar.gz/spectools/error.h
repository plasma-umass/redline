#ifndef __SHOW_ERROR_H__
#define __SHOW_ERROR_H__
#include <errno.h>

void show_error(char *, ...);

#endif

