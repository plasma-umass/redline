#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "sched_spec.h"
#include "error.h"

void usage(void);
extern char *optarg;
extern int optind;

void init_spec_input(struct spec_input *input)
{
	input->policy		= -1;
	input->flag			= 0;	
	input->priority	= -1;
	input->nice			= -1;
	input->load			= -1;
	input->window		= -1;
	input->percent	= -1;
	input->memory		= -1;
	input->io				= -1;
}

int get_policy_number(char *p)
{
	char val;
	int policy = -1;

	val = *p;
	switch(val) {
		case 'N':
			policy = SCHED_NORMAL;
			break;
		case 'F':
			policy = SCHED_FIFO;
			break;
		case 'R':
			policy = SCHED_RR;
			break;
		case 'B':
			policy = SCHED_BATCH;
			break;
		case 'I':
		 	policy = SCHED_ISO;
			break;
		case 'D':
			policy = SCHED_IDLE;
			break;
		case 'A':
			policy = SCHED_RESPO;
			break;
		case 'T':
			policy = SCHED_THPUT;
			break;
	}
	return policy;
}

/* 
 * Set task scheduling policy to be fair time-sharing. When setting
 * the policy, kernel system call sched_setscheduler() requires its 
 * static priority to be zero. Therefore, another system call is needed
 * to set proper nice value if needed.
 *
 * SCHED_IDLE is handled specially inside the kernel, therefore its
 * sched_priority and nice value is essentially useless, since kernel
 * will give it a special weight.
 */
int set_task_fair(pid_t pid, int policy, struct spec_input *input)
{
	struct sched_spec spec;
	int retval = -1;

	memset((void *)&spec, 0, sizeof(struct sched_spec));
	spec.sched_priority = 0;	

	retval = sched_setspec(pid, policy, &spec);
	if (retval) {
		show_error("sched_setspec() fail, policy %d", policy);
		return retval;
	}

	/* nice value is not provided? use default 0 */
	if (input->nice == -1) 
		input->nice = 0;

	/* use set_priority() to set proper nice value */
	if (policy != SCHED_IDLE && input->nice != 0) {
		retval = setpriority(PRIO_PROCESS, pid, input->nice); 
		if (retval) {
			show_error("setpriority() fail");
			return retval;
		}
	}
	return retval;
}

/*
 * Set task scheduling policy to be real-time (FIFO/RR). In SpecOS
 * the these policy no longer exists. Kernel internally translate
 * them into RESPO class. These calls exist for compatibility reasons.
 *
 * Currenly, most rt tasks are kernel threads. In order to make sure
 * their performance, their specification is inheritable, and kernel
 * internally ensures that. 
 */
int set_task_rt(pid_t pid, int policy, struct spec_input *input)
{
	struct sched_spec spec;
	int retval = -1;

	memset((void *)&spec, 0, sizeof(struct sched_spec));
	spec.sched_priority = input->priority;

	if (!(input->flag & SPEC_APP_LAUNCHER) &&
			(input->flag & SPEC_RECURSIVE) &&
			(input->flag & SPEC_PINNED)) {
		show_error("Beside APP_LAUNCHER, RECURSIVE specification must not be PINNED");
		return(retval);
	}

	/* make it inheritable spec */
	spec.flags |= SPEC_INHERIT;
	retval = sched_setspec(pid, policy, &spec);
	if (retval) {
		show_error("sched_setspec() fail, policy %d", policy);
		return retval;
	}

	return retval;
}

/*
 * Set task scheduling policy to be response time driven (RESPO)
 */
int set_task_respo(pid_t pid, int policy, struct spec_input *input)
{
	struct sched_spec spec;
	int retval = -1;

	memset((void *)&spec, 0, sizeof(struct sched_spec));

	/* 
	 * currently force sched_priority to be 0, so that it is treated 
	 * as a task has nice value 0 during boost mode. Another system
	 * call is need to set nice value, if really needed.
	 */ 
	spec.sched_priority = 0;

	if (input->load == -1 || input->window == -1) {
		show_error("either load or window is not set for RESPO task");
		return(retval);
	}

	if (input->load > (input->window * 90)/100) {
		show_error("Too large load. load/window should be less that 90%");
		return(retval);
	}

	if (!(input->flag & SPEC_APP_LAUNCHER) &&
			(input->flag & SPEC_RECURSIVE) &&
			(input->flag & SPEC_PINNED)) {
		show_error("Beside APP_LAUNCHER, RECURSIVE specification must not be PINNED");
		return(retval);
	}

	input->flag |= SPEC_RESPO;

	spec.respo_load = input->load;
	spec.respo_window = input->window;
	spec.flags = input->flag;

	retval = sched_setspec(pid, policy, &spec);
	if (retval) {
		show_error("sched_setspec() fail, policy %d", policy);
		return(retval);
	}
	return retval;
}

/* 
 * THPUT class is not implemented in the kernel yet
 */
int set_task_thput(pid_t pid, int policy, struct spec_input *input)
{
	struct sched_spec spec;
	int retval = -1;

	memset((void *)&spec, 0, sizeof(struct sched_spec));

	show_error("THPUT is not implemented in the kernel yet");
	return retval;
}


int main(int argc, char **argv) 
{
	int retval = 0;
	int pid, count, c;
	char **real_args;
	struct spec_input input;

	if (argc < 2) {
		usage();
		return(0);
	}

	init_spec_input(&input);
	/* 
	 * -P policy no -l respo_load, -r respo_window, -s batch share, -p priority
	 * -n nice -m memory, -i io, -I inherit, -F recursive, -X revokable
	 */
	while((c = getopt(argc, argv, "LAIFXES:V:p:n:l:w:s:m:i:")) != -1) {
		switch(c) {
			case 'S':
				input.policy = get_policy_number(optarg);
				if (input.policy == -1) {
					show_error("Unknown Policy: %s", optarg);
					return(1);
				}
				break;
			case 'V':
				input.policy = atoi(optarg);
				if (input.policy < SCHED_NORMAL || input.policy > SCHED_THPUT) {
					show_error("Unknow Policy: %d, Valid [0 - 7]", input.policy);
					return(1);
				}
				break;
			case 'L':
				input.flag |= SPEC_APP_LAUNCHER;
				break;
			case 'A':
				input.flag |= SPEC_APP_LEADER;
				break;
			case 'E':
				input.flag |= SPEC_EXTENDIBLE;
				break;
			case 'I':
				input.flag |= SPEC_INHERIT;
				break;
			case 'F':
				input.flag |= SPEC_RECURSIVE;
				break;
			case 'X':
				input.flag |= SPEC_PINNED;
				break;
			case 'p':
				input.priority = atoi(optarg);
				if (input.priority < 0 || input.priority > 99) {
					show_error("Priority for FIFO/RR should be in [0, 99]: %d", input.priority);
					return(1);
				}
				break;
			case 'n':
				input.nice = atoi(optarg);
				if (input.nice < -20 || input.nice > 20) {
					show_error("Nice for NORMAL/BATCH/IDLE should should be in [-20, 20]: %d", 
											input.nice);
					return(1);
				}
				break;
			case 'l':
				input.load = atoi(optarg);
				if (input.load <= 0 || input.load > 1000) {
					show_error("Load for RESPO should be in (0, 1000]: %d", input.load);
					return(1);
				}
				break;
			case 'w':
				input.window = atoi(optarg);
				if (input.window <= 0 || input.window > 1000) {
					show_error("Window for RESPO should be in (0, 1000]: %d", input.window);
					return(1);
				}
				break;
			case 's':
				input.percent = atoi(optarg);
				//if (input.percent <= 0 || input.percent >= 90) {
				//	show_error("Percent for THPUT should be in (0, 90): %d", input.percent);
				//	return(1);
				//}
				break;
			case 'm':
				input.memory = atoi(optarg);
				break;
			case 'i':
				input.io = atoi(optarg);
				break;

			default:
				printf("%c\n", c);
				usage();
				return(1);
		}
	}

	count = argc - optind;
	if (count != 1) {
		usage();
		return(0);
	}

	real_args = argv + optind;
	if (!(isdigit(*real_args[0]))) {
		show_error("Invalid pid: %s", real_args[0]);
		return(0);
	}

	pid = atoi(real_args[0]);

	switch (input.policy) {
		case SCHED_NORMAL:
		case SCHED_BATCH:
		case SCHED_IDLE:
			retval = set_task_fair(pid, input.policy, &input);
			break;
		case SCHED_FIFO:
		case SCHED_RR:
			retval = set_task_rt(pid, input.policy, &input);
			break;
		case SCHED_RESPO:
			retval = set_task_respo(pid, input.policy, &input);
			break;
		case SCHED_THPUT:
			retval = set_task_thput(pid, input.policy, &input);
			break;
		case SCHED_ISO:
			show_error("ISO is not supported");
	}

	return retval;
}

void usage(void) 
{
	printf(
				"Set scheduling policies/specification, GPL'd, NO WARRANTY\n" \
				"USAGE: set_pid_spec [OPTIONS] PID			- set PID with scheduling specification\n" \
				"\n"\
				"Set scheduling policies:\n" \
				"  -S (N|B) -n NICE   for SCHED_NORMAL, SCHED_BATCH, with nice value set\n" \
				"  -S D               for SCHED_IDLE, not nice value needed\n" \
				"  -S (F|R) -p PRIO   for SCHED_FIFO, SCHED_RR, root only, with a priority\n" \
				"  -S I     -p PRIO   for SCHED_ISO, not in SpecOS, for compatibility only\n" \
				"  -S A -l LOAD -w WINDOW \n" \
				"                     for SCHED_RESPO, root only, with a load and response window\n" \
				"  -S T -s SHARE      for SCHED_THPUT, root only, with a cpu share\n" \
				"\n"
				"Options\n"
				"  -S POLICY          select the scheduling policy\n" \
				"                     N: SCHED_NORMAL, F: SCHED_FIFO, R: SCHED_RR, B: SCHED_BATCH\n" \
				"                     I: SCHED_ISO, D: SCHED_IDLE, A: SCHED_RESPO, T: SCHED_THPUT\n" \
				"  -V POLICY          using number for choosing policy 0-7\n" \
				"  -p PRIORITY        the static priority, for FIFO/RR/ISO [0,99]\n" \
				"  -n NICE            niceness for NORMAL,BATCH [-20,20]\n" \
				"  -l LOAD            set the amount of load for RESPO (0,1000]\n" \
				"  -w WINDOW          set the response window for RESPO (0,2000]\n" \
				"  -s SHARE           set the CPU share for THPUT (0,90)\n" \
				"  -I                 children inherit my spec?\n" \
				"  -R                 force my children recursively use my spec?\n" \
				"  -X                 can kernel revoke my spec in case of overloading?\n" \
				"  -L                 application launcher flag\n" \
				"  -A                 application leader flag\n" \
				"  -E                 specification extendible\n" \
				);
}
