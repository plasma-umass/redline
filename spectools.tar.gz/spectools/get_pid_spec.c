#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <ctype.h>
#include <stdarg.h>
#include <string.h>

#include "error.h"
#include "sched_spec.h"

char *POLICY[] = {
	"NORMAL",
	"FIFO",
	"RR",
	"BATCH",
	"ISO",
	"IDLE",
	"RESPO",
	"THPUT",
	0,
};

void usage(void);
extern char *optarg;
extern int optind;

void show_specification(pid_t pid, int policy, struct sched_spec *spec)
{
	printf("%6d %8s ", pid, POLICY[policy]);
	printf("%4d %4d %4d ", spec->respo_load, spec->respo_window, spec->batch_percent);
	if (policy == SCHED_FIFO || policy == SCHED_RR || policy == SCHED_ISO) 
		printf("%3d(%3d) ", spec->sched_priority, spec->sched_priority);
	else
		printf("%3d(%3d) ", spec->sched_priority, (spec->sched_priority - 100 - 20));
	printf("%3d %3d ", spec->memory, spec->io);

	//if (spec->flags & SPEC_RESPO)
	//	printf("6");
	//else if (spec->flags & SPEC_THPUT)
	//	printf("7");
	//else
	//	printf("0");
	printf("%2d(%2d)", policy, spec->policy);

	if (spec->flags & SPEC_APP_LAUNCHER)
		printf("L");
	else 
		printf("-");
	if (spec->flags & SPEC_APP_LEADER)
		printf("A");
	else
		printf("-");
	if (spec->flags & SPEC_INHERIT)
		printf("I");
	else
		printf("-");
	if (spec->flags & SPEC_RECURSIVE)
		printf("R");
	else
		printf("-");
	if (spec->flags & SPEC_PINNED)
		printf("X");
	else
		printf("-");
	if (spec->flags & SPEC_EXTENDIBLE)
		printf("E");
	else
		printf("-");
	if (spec->flags & SPEC_EXTENDED)
		printf("T");
	else
		printf("-");

	switch (spec->spec_state) {
		case SPEC_NO_SPEC:
			printf("S(NS)"); break;
		case SPEC_FORK_NO_SPEC:
			printf("S(FN)"); break;
		case SPEC_FORK_CHECK:
			printf("S(FC)"); break;
		case SPEC_EXEC_CHECK:
			printf("S(EC)"); break;
		case SPEC_SYSCALL_CHECK:
			printf("S(CC)"); break;
		case SPEC_ACCEPTED:
			printf("S(AP)"); break;
		case SPEC_REJECTED:
			printf("S(RJ)"); break;
		case SPEC_REVOKED:
			printf("S(RV)"); break;
	}
	printf("\n");
}

int main(int argc, char **argv) 
{
	struct sched_spec spec;
	int policy, pid, count;
	int retval = 0;
	char **real_args;

	count = argc - optind;
	if (count != 1) {
		usage();
		return(0);
	}

	real_args = argv + optind;
	if (!(isdigit(*real_args[0]))) {
		show_error("Invalid pid: %s", real_args[0]);
		return(0);
	}

	pid = atoi(real_args[0]);

	policy = sched_getscheduler(pid);
	if (policy < 0) {
		show_error("getscheduler() fail on pid %d", pid);
		return(1);
	}

	memset((void *)&spec, 0, sizeof(struct sched_spec));
	retval = sched_getspec(pid, &spec);
	if (retval) {
		show_error("getspec() fail on pid %d", pid);
		return(1);
	}

	show_specification(pid, policy, &spec);
	return(0);
}

void usage(void) 
{
	printf(
				"Get specification of a process, GPL'd, NO WARRANTY\n" \
				"USAGE: get_pid_spec PID				- get PID with its specification\n" \
				);
	
}
