#!/usr/bin/perl 

if ($] < 5) {
	print "Perl version lower than 5 in /usr/bin ... existing\n";
	exit;
}

$get_pid_spec = "";
if (-e "/usr/bin/get_pid_spec") {
	$get_pid_spec = "/usr/bin/get_pid_spec";
}
elsif (-e "get_pid_spec") {
	$get_pid_spec = "./get_pid_spec";
}
else {
	print "get_pid_spec not found\n";
	exit;
}

if (!(-x $get_pid_spec)) {
	print "$get_pid_spec is not an executable\n";
	exit;
}

open (PS, "ps -A |")
	or die "Could not open ps for reading: $!";
$_ = <PS>; # skip one line
while (<PS>) {
	@linecomp = split;
	$pid = $linecomp[0];
	if ($pid =~ /^\d+$/) {
		printf "%20s ", $linecomp[3];
		$this_pid = $pid;
		process_one_pid();
	}
}
close PS;

sub process_one_pid {
	$job = "$get_pid_spec $this_pid";
	system($job);
}

