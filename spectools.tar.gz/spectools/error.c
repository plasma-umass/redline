#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "error.h"

void show_error(char *fmt, ...)
{
	va_list args;
	//int old_errno = errno;

	printf("ERROR: ");
	va_start(args, fmt);
	vprintf(fmt, args);
	va_end(args);
	printf("\n");

	if (errno) {
		printf("SYS_MSG %d: %s\n", errno, strerror(errno));
	}
}
