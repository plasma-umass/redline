#ifndef __SCHED_SPEC_H__
#define __SCHED_SPEC_H__

#include <linux/unistd.h>

#undef SCHED_NORMAL
#undef SCHED_FIFO
#undef SCHED_RR
#undef SCHED_BATCH
#undef SCHED_ISO
#undef SCHED_IDLE
#define SCHED_NORMAL	0
#define SCHED_FIFO		1
#define SCHED_RR			2
#define SCHED_BATCH		3
#define	SCHED_ISO			4 
#define SCHED_IDLE		5
#define SCHED_RESPO		6
#define SCHED_THPUT		7

#define SPEC_NORMAL					0x000000
#define SPEC_RESPO					0x000001
#define SPEC_THPUT					0x000002
#define SPEC_INHERIT	  		0x001000
#define SPEC_RECURSIVE			0x002000
#define SPEC_PINNED					0x004000
#define SPEC_APP_LAUNCHER		0x008000
#define SPEC_APP_LEADER			0x010000
#define SPEC_EXTENDIBLE			0x020000
//#define SPEC_DISABLED				0x040000
//#define SPEC_REVOKED				0x080000
#define SPEC_EXTENDED				0x100000

/* SPEC state for a task, change to enum later */
#define SPEC_NO_SPEC				0	/* No specification of this task */
#define SPEC_FORK_CHECK			1 /* Forked, not checked. Scheduler check it 
													  		 after 1ms. may change to 0, 4, 5 */
#define SPEC_FORK_NO_SPEC   2
#define SPEC_EXEC_CHECK			3 /* Exec get spec, check it immediately,
																 may change to 0, 4, 5 */
#define SPEC_SYSCALL_CHECK	4 /* when sched_setscheduler()/sched_setspec()
														     called by, notify check */
#define SPEC_ACCEPTED			5 /* pass admission check and accepted */
#define SPEC_REJECTED				6 /* does not pass admission check */
#define SPEC_REVOKED				7 /* spec revoked when system is overloaded */


struct sched_spec {
	int sched_priority;

	int policy;
	unsigned int spec_state;
	unsigned int flags;
	unsigned int respo_load;
	unsigned int respo_window;
	unsigned int batch_percent;		/* Not implemented yet */
	unsigned int memory;					/* Not implemented yet */
	unsigned int io;							/* Not implemented yet */
};

_syscall3(long, sched_setspec, pid_t, pid, int, policy, struct sched_spec *, spec);
_syscall2(long, sched_getspec, pid_t, pid, struct sched_spec *, spec);

struct spec_input {
	int policy;
	int flag;
	int priority;
	int nice;
	int load;
	int window;
	int percent;
	int memory;
	int io;
};

#endif
