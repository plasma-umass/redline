#!/usr/bin/perl 

if ($] < 5) {
	print "Perl version lower than 5 in /usr/bin ... existing\n";
	exit;
}

$specification = "/etc/spec/specification.tab";
$set_pid_spec  = "";

if (-e "/usr/bin/set_pid_spec") {
	$set_pid_spec = "/usr/bin/set_pid_spec";
}
elsif (-e "set_pid_spec") {
  # look for local directory
	$set_pid_spec = "./set_pid_spec";
}
else {
	print "set_pid_spec not found\n";
	exit;
}

if (!(-x $set_pid_spec)) {
	print "$set_pid_spec is not an executable\n";
	exit;
}

#
# Get process running in the system
#
%pid_name = ();
open (PS, "ps -A |")
	or die "Could not open ps for reading: $!";
$_ = <PS>;
while (<PS>) {
	@linecomp = split;
	$pid = $linecomp[0];
	if ($pid =~ /^\d+$/) {
		$pid_name{$pid} = $linecomp[3];
	}
}

#
# Open spec database
#
open (SPEC, "< $specification")
	or die "Could not open $specification for reading: $!";

while (<SPEC>) {
	if (/^;/ || /^\s+/) { # skip comments and empty lines
		next;
	}
	if (!/^\$/) {
		print "Warning: Unknown line, has to see \$ first for path\n";
		next;
	}
	
	# we have a pathname
	$tempname = $_;
	$tempname =~ s/[\$\s]//g;

	if ($tempname =~ m/^\//) {
		$temp = <SPEC>;        # read one more line for spec, and skip it
		next;
	}

	# find what we are looking for: kernelthread, had name but no path
	$name = $_;
	$spec = <SPEC>;
	$tempspec = $spec;

	if (!($tempspec =~ m/^\#/)) {
		print "Invalid spec line, should start with \#\n";
		next;
	}

	$name =~ s/[\$\s]//g;
	$spec =~ s/[\#\s]//g;
	#print "$name: $spec\n";
	process_one_name();

}
close SPEC;

sub process_one_name {
	#
	# We have a _name_ for the process, and a _spec_ for it. 
	# parse the spec first
	#
	@speccomp = split /:/, $spec; 

	foreach $pid (sort {$a <=> $b} keys %pid_name) {
		if ($name eq $pid_name{$pid}) {
			$current_pid = $pid;
			#print "$name: @speccomp\n";
			process_one_pid();
		}
	}
}


sub process_one_pid {
	#
	# We have a pid, and an array of specs for this pid
	#

	$command = "$set_pid_spec ";

	# pick scheduler
	$command = $command."-V $speccomp[0] ";

	# check flags
	if ($speccomp[7] != 0) { # inherit
		$command = $command."-I ";
	}
	if ($speccomp[8] !=0) { # recursive
		$command = $command."-F ";
	}
	if ($speccomp[9] !=0) { # revokable
		$command = $command."-X ";
	}
	if ($speccomp[10] != 0) { # extendible
	  $command = $command."-E ";
  }	
	if ($speccomp[11] != 0) { # app launcher
		$command = $command."-L ";
	}


	# respo_load, respo_window
	$command = $command."-l $speccomp[1] -w $speccomp[2] ";
	# batch_percent, priority/weight
	$command = $command."-s $speccomp[3] -n $speccomp[4] ";
	# memory, io
	$command = $command."-m $speccomp[5] -i $speccomp[6] ";

	#print "$name, $pid, $current_pid\n";
	$command = $command."$current_pid";
	#print "$command\n";
	system($command);

}
