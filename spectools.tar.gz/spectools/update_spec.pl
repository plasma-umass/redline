#!/usr/bin/perl 

if ($] < 5) {
	print "Perl version lower than 5 in /usr/bin ... existing\n";
	exit;
}

$spec_file = "/etc/spec/specification.tab";
$spec_dir  = "/etc/spec/";

$clean_spec  = "rm ".$spec_dir."*.spec > /dev/null";
system($clean_spec);

open (SPEC, "< $spec_file")
	or die "Could not open $spec_file for reading:$!";

while (<SPEC>) {
	if (/^;/ || /^\s+/) { # skip comments and empty lines
		next;
	}

	$tempname = $_;
	$pathline = $tempname;
	$specline = <SPEC>;	

	# figure out specfile name
	$tempname =~ s/[\$\s]//g;
	if (!($tempname =~ m/^\//)) { # skip kernel thread that do not execve
		next;
	}

	@pathcomp = split /\//, $tempname;
	$specname = $spec_dir.$pathcomp[$#pathcomp].".spec";

	# print "$specname\n";
	# TODO: we can verify the spec here, (kernel have to do it anyway)
	
	# create the new spec file
	open (SPEC_FILE, "> $specname")
		or warn "Could not open $specname for writing: $!";
	print SPEC_FILE $pathline;
	print SPEC_FILE $specline;
	close SPEC_FILE;
	
	# make it executable, since now in kernel we use open_exec() 
        # to load spec files
	chmod(0644, $specname)
		or warn "Could not chmod for $specname: $!";
}
close SPEC;
