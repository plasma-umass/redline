#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <unistd.h>

#define LOOP_SIZE 50000000
#define FORK_SIZE 2000

static void busy_loop(void)
{
	unsigned long good = 0;
	unsigned long count = 0;

	for ( ; ; ) {
		good++;

		if (good > LOOP_SIZE) {
			good = good / LOOP_SIZE;
			//usleep(7000);
			count++;
		}

		if (count > LOOP_SIZE) 
			count = count / LOOP_SIZE;
	}
}

int main(int argc, char *argv[]) 
{
	int retval = 0;
	int fork_count;
	pid_t child_pid;
	int fork_size = 2;

	fork_size = atoi(argv[1]);
	printf("Fork %d children\n", fork_size);

	for (fork_count = 0; fork_count < fork_size; fork_count++) {
		
		if ((child_pid = fork()) < 0) {
			printf("Fork child error\n");
			break;
		}

		/* fork success  && I am the child, go busy*/
		if ( child_pid == 0) {
			busy_loop();
		} else {
			printf("Forked child count %d, pid %d\n",
				fork_count, child_pid);
		}

		/* parent, hmmm, go fork again, haha ... */
	}

	printf("Fork %d children done\n", fork_count);
	busy_loop();
}
