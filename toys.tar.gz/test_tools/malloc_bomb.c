#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <errno.h>

/* 1G size. */
#define SIZE_IN_MB   300
#define PAGES_PER_MB 256
#define MY_BYTES_PER_PAGE 4096

int main(int argc, char **argv)
{
    char * pStart;
    int i, pages, size, mb;
		char c;

		mb = atoi(argv[1]);
		mb = mb ? mb : SIZE_IN_MB;
    pages = mb * PAGES_PER_MB;
    size  = pages * MY_BYTES_PER_PAGE;

    printf("pages is %d\n", pages);

    pStart = mmap(NULL, size , PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if(pStart == MAP_FAILED) {
			printf("map failed with error %d!!!!!\n", errno);
    	return -1;
    }
//    while(pStart != NULL)
//  {
	for(i = 0; i < pages; i++)
        {
//	    printf("i is %d\n", i);
	    pStart[i*MY_BYTES_PER_PAGE] = 1;
	//    *(pStart+i*MY_BYTES_PER_PAGE) = 1;
        }
//   }
  printf("Writing Finished\n");

	while (pStart != NULL) {
		for (i = 0; i < pages; i++)
//			c = pStart[i * MY_BYTES_PER_PAGE];
			pStart[i * MY_BYTES_PER_PAGE] = 'a'; 
	}

}
