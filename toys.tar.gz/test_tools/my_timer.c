#include "my_timer.h"

#define MAX_BUFFER 32768
double cpu_freq = 1.0;

void getTime(unsigned long *low, unsigned long *high)
{
	unsigned int tlow, thigh;

	  asm volatile ("rdtsc"
				  : "=a"(tlow),
				  "=d" (thigh));

	*low  = tlow;
	*high = thigh;
}

struct time_intv *createTimer(void)
{
	struct time_intv *timer;

	timer = (struct time_intv *)malloc(sizeof(struct time_intv));
	timer->start_low  = 0;
	timer->start_high = 0;
	timer->end_low    = 0;
	timer->end_high   = 0;
	timer->elapsed    = 0;
	 
	return timer;
}

void destroyTimer(struct time_intv *timer)
{
	free(timer);
}

void startTimer(struct time_intv *timer)
{
	getTime(&timer->start_low, &timer->start_high);
}

double __time_interval(unsigned long low1, unsigned long high1,
										unsigned long low2, unsigned long high2)
{
	double elapsed;
	elapsed = (double)(low2 - low1) + (double)(UINT_MAX)*(double)(high2 - high1);
	if (low2 < low1)
		elapsed -= (double)UINT_MAX;
	return elapsed;
}

void stopTimer(struct time_intv *timer)
{
	getTime(&timer->end_low, &timer->end_high);
	timer->elapsed = __time_interval(timer->start_low, timer->start_high,
																 timer->end_low, timer->end_high);
}

double time_interval(unsigned long low1, unsigned long high1,
										unsigned long low2, unsigned long high2)
{
	double elapsed = __time_interval(low1, high1, low2, high2);
	return elapsed/cpu_freq;
}

double getElapsedTime(struct time_intv *timer)
{
	return timer->elapsed/cpu_freq;
}

void showElapsedTime(struct time_intv *timer, char *msg)
{
	printf("%s: Time %16.6f\n", msg, timer->elapsed/cpu_freq);
}

double getFreq(void)
{
	double freq = 0.0;
	const char searchStr[] = "cpu MHz\t\t: ";
	char line[MAX_BUFFER];
	int fd = open("/proc/cpuinfo", O_RDONLY);
	read (fd, line, MAX_BUFFER);
	char *pos = strstr(line, searchStr);
	if (pos) {
		float f;
		pos += strlen(searchStr);
		sscanf(pos, "%f", &f);
		freq = (double) f * 1000000.0;
	}
	cpu_freq = freq;
	return freq;
}

