#ifndef __MY_TIMER_H__
#define __MY_TIMER_H__

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>



/************************************************************/
/* Timer 
 */
struct time_intv {
	unsigned long start_low;
	unsigned long start_high;
	unsigned long end_low;
	unsigned long end_high;
	double elapsed;
};

void getTime(unsigned long *low, unsigned long *high);
struct time_intv *createTimer(void);
void destroyTimer(struct time_intv *timer);
void startTimer(struct time_intv *timer);
void stopTimer(struct time_intv *timer);
double getElapsedTime(struct time_intv *timer);
void showElapsedTime(struct time_intv *timer, char *msg);
double getFreq(void);
double time_interval(unsigned long low1, unsigned long high1,
										 unsigned long low2, unsigned long high2);

#endif
