#define _GNU_SOURCE /* for O_DIRECT */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define SIZE_IN_MB 100
#define PAGES_PER_MB 256
#define MY_BYTES_PER_PAGE 4096

/* 
 * AGRV[1]: io size
 * AGRV[2]: 0 - iosize is in MB
 * 	    1 - iosize is in PAGE
 * ARGV[3]: postfix for file name
 * ARGV[4]: 0 - write without fsync
 * 	    1 - write then all fsync
 *	    2 - write, sync on each page
 * 	    3 - direct write whole buffer with O_DIRECT
 * 	    4 - direct write for each page in buffer
 * ARGV[5]: 0 - do not collect timing information
 * 	    1 - collect timing information
 * ARGV[6]: 0 - just once
 *          1 - keep writing, lseek to begining
 */

#define WRITE_NOSYNC 				0
#define WRITE_SYNC_WHOLE  	1
#define WRITE_SYNC_PAGE   	2
#define WRITE_DIRECT_WHOLE	3
#define WRITE_DIRECT_PAGE 	4

#define MAX_BUFFER 32768
double cpu_freq = 1.0;

/************************************************************/
/* Timer 
 */
struct time_intv {
	unsigned long start_low;
	unsigned long start_high;
	unsigned long end_low;
	unsigned long end_high;
	double elapsed;
};

void getTime(unsigned long *low, unsigned long *high)
{
	unsigned int tlow, thigh;

	  asm volatile ("rdtsc"
				  : "=a"(tlow),
				  "=d" (thigh));

	*low  = tlow;
	*high = thigh;
}

struct time_intv *createTimer(void)
{
	struct time_intv *timer;

	timer = (struct time_intv *)malloc(sizeof(struct time_intv));
	timer->start_low  = 0;
	timer->start_high = 0;
	timer->end_low    = 0;
	timer->end_high   = 0;
	timer->elapsed    = 0;
	 
	return timer;
}

void destroyTimer(struct time_intv *timer)
{
	free(timer);
}

void startTimer(struct time_intv *timer)
{
	getTime(&timer->start_low, &timer->start_high);
}

void stopTimer(struct time_intv *timer)
{
	double elapsed;

	getTime(&timer->end_low, &timer->end_high);
	elapsed = (double)(timer->end_low - timer->start_low) +
						(double)(UINT_MAX)*(double)(timer->end_high - timer->start_high);
	if (timer->end_low < timer->start_low)
		elapsed -= (double)UINT_MAX;
	timer->elapsed = elapsed;
}

double getElapsedTime(struct time_intv *timer)
{
	return timer->elapsed;
}

void showElapsedTime(struct time_intv *timer, char *msg)
{
	printf("%s: Time %16.6f\n", msg, getElapsedTime(timer)/cpu_freq);
}

static double getFreq(void)
{
	double freq = 0.0;
	const char searchStr[] = "cpu MHz\t\t: ";
	char line[MAX_BUFFER];
	int fd = open("/proc/cpuinfo", O_RDONLY);
	read (fd, line, MAX_BUFFER);
	char *pos = strstr(line, searchStr);
	if (pos) {
		float f;
		pos += strlen(searchStr);
		sscanf(pos, "%f", &f);
		freq = (double) f * 1000000.0;
	}
	return freq;
}

/************************************************************/

struct write_control {
	int pages;
	int bytes;
	int mode;
	char filename[128];
	int timing;
	int repeat;
};

void write_nosync(struct write_control *wc) 
{
	int fd = -1, i;
	char *buffer;
	struct time_intv *write_time;

	write_time = createTimer();

	fd = open(wc->filename, O_RDWR|O_CREAT, 0777);

	/* Prepare for data buffer */
	buffer = mmap(NULL, MY_BYTES_PER_PAGE, PROT_READ|PROT_WRITE, 
						MAP_PRIVATE|MAP_ANON, -1, 0);
	for (i = 0; i < MY_BYTES_PER_PAGE; i++) {
		buffer[i] = i;
	}

	do {
		lseek(fd, 0, SEEK_SET);
		startTimer(write_time);
		for (i = 0; i < wc->pages; i++) {
			write(fd, buffer, MY_BYTES_PER_PAGE);
		}
		stopTimer(write_time);

		if (wc->timing) {
			showElapsedTime(write_time, "Write, no Sync");
		}
	} while((--wc->repeat > 0));

	destroyTimer(write_time);
	close(fd);
	
}

void write_sync_whole(struct write_control *wc)
{
	int fd = -1, i;
	char *buffer;
	struct time_intv *write_time, *sync_time;

	write_time = createTimer();
	sync_time  = createTimer();

	fd = open(wc->filename, O_RDWR|O_CREAT, 0777);

	/* Prepare for data buffer */
	buffer = mmap(NULL, MY_BYTES_PER_PAGE, PROT_READ|PROT_WRITE, 
						MAP_PRIVATE|MAP_ANON, -1, 0);
	for (i = 0; i < MY_BYTES_PER_PAGE; i++) {
		buffer[i] = i;
	}

	do {
		lseek(fd, 0, SEEK_SET);
		startTimer(write_time);
		for (i = 0; i < wc->pages; i++) {
			write(fd, buffer, MY_BYTES_PER_PAGE);
		}
		stopTimer(write_time);

		startTimer(sync_time);
		fsync(fd);
		stopTimer(sync_time);

		if (wc->timing) {
			showElapsedTime(write_time, "Write, Whole, Sync: write()");
			showElapsedTime(sync_time, "Write, Whole, Sync: fsync()");
		}
	} while ((--wc->repeat > 0));

	destroyTimer(write_time);
	destroyTimer(sync_time);
	close(fd);
}

void write_sync_page(struct write_control *wc)
{
	int fd = -1, i;
	char *buffer;
	struct time_intv *write_time;

	write_time = createTimer();

	fd = open(wc->filename, O_RDWR|O_CREAT, 0777);

	/* Prepare for data buffer */
	buffer = mmap(NULL, MY_BYTES_PER_PAGE, PROT_READ|PROT_WRITE, 
						MAP_PRIVATE|MAP_ANON, -1, 0);
	for (i = 0; i < MY_BYTES_PER_PAGE; i++) {
		buffer[i] = i;
	}

	do {
		lseek(fd, 0, SEEK_SET);
		startTimer(write_time);
		for (i = 0; i < wc->pages; i++) {
			write(fd, buffer, MY_BYTES_PER_PAGE);
			fsync(fd);
		}
		stopTimer(write_time);

		if (wc->timing) {
			showElapsedTime(write_time, "Write, Page, Sync");
		}
	} while ((--wc->repeat > 0));
	destroyTimer(write_time);
	close(fd);
}

void write_direct_whole(struct write_control *wc)
{
	int fd = -1, i;
	char *buffer;
	struct time_intv *write_time;

	write_time = createTimer();
	fd = open(wc->filename, O_RDWR|O_CREAT|O_DIRECT, 0777);

	/* Prepare for data buffer */
	buffer = mmap(NULL, wc->bytes, PROT_READ|PROT_WRITE, 
						MAP_PRIVATE|MAP_ANON, -1, 0);
	for (i = 0; i < wc->pages; i++) {
		buffer[i * MY_BYTES_PER_PAGE] = i;
	}

	do {
		lseek(fd, 0, SEEK_SET);
		startTimer(write_time);
		write(fd, buffer, wc->bytes);
		stopTimer(write_time);

		if (wc->timing) {
			showElapsedTime(write_time, "Write, Whole, Direct");
		}
	} while ((--wc->repeat > 0));

	destroyTimer(write_time);
	close(fd);
}

void write_direct_page(struct write_control *wc)
{
	int fd = -1, i;
	char *buffer;
	struct time_intv *write_time;

	write_time = createTimer();

	fd = open(wc->filename, O_RDWR|O_CREAT|O_DIRECT, 0777);

	/* Prepare for data buffer */
	buffer = mmap(NULL, wc->bytes, PROT_READ|PROT_WRITE, 
						MAP_PRIVATE|MAP_ANON, -1, 0);
	for (i = 0; i < wc->pages; i++) {
		buffer[i * MY_BYTES_PER_PAGE] = i;
	}

	do {
		lseek(fd, 0, SEEK_SET);
		startTimer(write_time);
		for (i = 0; i < wc->pages; i++) {
			write(fd, buffer + (i*MY_BYTES_PER_PAGE), MY_BYTES_PER_PAGE);
		}
		stopTimer(write_time);

		if (wc->timing) {
			showElapsedTime(write_time, "Write, Page, Direct");
		}
	} while ((--wc->repeat > 0));

	destroyTimer(write_time);
	close(fd);
}

int main (int argc, char **argv)
{
	int iosize, inpage, postfix;
	struct write_control wc;

	iosize = atoi(argv[1]);
	inpage = atoi(argv[2]);
	wc.pages = inpage ? iosize : iosize * PAGES_PER_MB;
	wc.bytes = wc.pages * MY_BYTES_PER_PAGE;

	postfix = atoi(argv[3]);
	sprintf(wc.filename, "/home/tingy/IO/testio%d", postfix);

	wc.mode = atoi(argv[4]);
	wc.timing = atoi(argv[5]);
	wc.repeat = atoi(argv[6]);

	cpu_freq = getFreq();

	switch (wc.mode) {
		case WRITE_NOSYNC:
			write_nosync(&wc);
			break;
		case WRITE_SYNC_WHOLE:
			write_sync_whole(&wc);
			break;
		case WRITE_SYNC_PAGE:
			write_sync_page(&wc);
			break;
		case WRITE_DIRECT_WHOLE:
			write_direct_whole(&wc);
			break;
		case WRITE_DIRECT_PAGE:
			write_direct_page(&wc);
			break;
		default:
			exit(0);
	}
	return 1;
}
